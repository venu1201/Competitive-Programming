const express=require("express")
const path=require("path")
const bodyParser=require("body-parser");
const mongoose=require('mongoose')
const app=express()
mongoose.connect('mongodb://localhost:27017/newlogin');
let db=mongoose.connection;
db.on('error', console.log.bind(console, "connection error"));
db.once('open', function(callback){
    console.log("connection succeeded");
})
app.use(express.static('.'))
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({
    extended: true
}));
app.get('/',(req,res)=>{
    res.sendFile(path.join(__dirname,'home.html'))
})
app.get('/login',(req,res)=>
{
    res.sendFile(path.join(__dirname,'login.html'))
})
app.get('/sign',(req,res)=>{
    res.sendFile(path.join(__dirname,'signup.html'))
})
app.get('/goback',(req,res)=>
{
    return res.redirect('/')
})
app.get('/phofwater',(req,res)=>{
    res.sendFile(path.join(__dirname,'phofwater.html'))
})
app.post('/signup', function(req,res){
    
    var email =req.body.email;
    var pass = req.body.password;
    var data = {
        "email":email,
        "password":pass,      
    }
    console.log(data)
    db.collection('logins').insertOne(data,function(err, collection){
        if (err) throw err;
        console.log("Record inserted Successfully");
              
    });
      
    return res.redirect('/');
})
app.listen(300)